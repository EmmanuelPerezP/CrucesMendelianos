# IO-Proyecto
Tecnológico de Costa Rica
Investigación de Operaciones
II Semestre 2018

Autores:
  Ana Rojas
  Iván López
  Silvia Calderòn

Proyecto de programación dinámica
