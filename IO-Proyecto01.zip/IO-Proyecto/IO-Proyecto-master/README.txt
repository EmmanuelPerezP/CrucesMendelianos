/**********************************************************
	
	Instituto Tecnológico de Costa Rica

	Curso:		Investigación de Operaciones

	Proyecto:	Programación dinámica

	Estudiantes:	Silvia Calderón
			Iván López
			Ana Rojas

**********************************************************/
Comandos:
	make desde la ubicación de IOProject para compilar.
	./IOProject desde la ubicación de IOProject para ejecutar.

